import{a as N4}from"./chunk-LTFFWF27.js";import{a as u2,c as c1}from"./chunk-5TBO732O.js";var e4=u2((X0,a4)=>{"use strict";var n0="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";a4.exports=n0});var f4=u2((K0,i4)=>{"use strict";var i0=e4();function o4(){}function n4(){}n4.resetWarningCache=o4;i4.exports=function(){function c(a,e,o,n,i,f){if(f!==i0){var r=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw r.name="Invariant Violation",r}}c.isRequired=c;function l(){return c}var s={array:c,bigint:c,bool:c,func:c,number:c,object:c,string:c,symbol:c,any:c,arrayOf:l,element:c,elementType:c,instanceOf:l,node:c,objectOf:l,oneOf:l,oneOfType:l,shape:l,exact:l,checkPropTypes:n4,resetWarningCache:o4};return s.PropTypes=s,s}});var t4=u2(($0,r4)=>{r4.exports=f4()();var Y0,Q0});var h0={prefix:"fas",iconName:"file-lines",icon:[384,512,[128441,128462,61686,"file-alt","file-text"],"f15c","M64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-288-128 0c-17.7 0-32-14.3-32-32L224 0 64 0zM256 0l0 128 128 0L256 0zM112 256l160 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-160 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zm0 64l160 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-160 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zm0 64l160 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-160 0c-8.8 0-16-7.2-16-16s7.2-16 16-16z"]};var g0={prefix:"fas",iconName:"calendar-days",icon:[448,512,["calendar-alt"],"f073","M128 0c17.7 0 32 14.3 32 32l0 32 128 0 0-32c0-17.7 14.3-32 32-32s32 14.3 32 32l0 32 48 0c26.5 0 48 21.5 48 48l0 48L0 160l0-48C0 85.5 21.5 64 48 64l48 0 0-32c0-17.7 14.3-32 32-32zM0 192l448 0 0 272c0 26.5-21.5 48-48 48L48 512c-26.5 0-48-21.5-48-48L0 192zm64 80l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm128 0l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zM64 400l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zm112 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16z"]};var b0={prefix:"fas",iconName:"user-vneck",icon:[448,512,[],"e461","M224 0a128 128 0 1 0 0 256A128 128 0 1 0 224 0zM145.9 314.9c-3.5-5.2-9.8-8-15.9-6.6C55.5 325.5 0 392.3 0 472l0 8c0 17.7 14.3 32 32 32l384 0c17.7 0 32-14.3 32-32l0-8c0-79.7-55.5-146.5-130-163.7c-6.1-1.4-12.4 1.4-15.9 6.6L237.3 412c-6.3 9.5-20.3 9.5-26.6 0l-64.8-97.1z"]};var S0={prefix:"fas",iconName:"sack-dollar",icon:[512,512,[128176],"f81d","M320 96L192 96 144.6 24.9C137.5 14.2 145.1 0 157.9 0L354.1 0c12.8 0 20.4 14.2 13.3 24.9L320 96zM192 128l128 0c3.8 2.5 8.1 5.3 13 8.4C389.7 172.7 512 250.9 512 416c0 53-43 96-96 96L96 512c-53 0-96-43-96-96C0 250.9 122.3 172.7 179 136.4c0 0 0 0 0 0s0 0 0 0c4.8-3.1 9.2-5.9 13-8.4zm84 88c0-11-9-20-20-20s-20 9-20 20l0 14c-7.6 1.7-15.2 4.4-22.2 8.5c-13.9 8.3-25.9 22.8-25.8 43.9c.1 20.3 12 33.1 24.7 40.7c11 6.6 24.7 10.8 35.6 14l1.7 .5c12.6 3.8 21.8 6.8 28 10.7c5.1 3.2 5.8 5.4 5.9 8.2c.1 5-1.8 8-5.9 10.5c-5 3.1-12.9 5-21.4 4.7c-11.1-.4-21.5-3.9-35.1-8.5c-2.3-.8-4.7-1.6-7.2-2.4c-10.5-3.5-21.8 2.2-25.3 12.6s2.2 21.8 12.6 25.3c1.9 .6 4 1.3 6.1 2.1c0 0 0 0 0 0s0 0 0 0c8.3 2.9 17.9 6.2 28.2 8.4l0 14.6c0 11 9 20 20 20s20-9 20-20l0-13.8c8-1.7 16-4.5 23.2-9c14.3-8.9 25.1-24.1 24.8-45c-.3-20.3-11.7-33.4-24.6-41.6c-11.5-7.2-25.9-11.6-37.1-15c0 0 0 0 0 0l-.7-.2c-12.8-3.9-21.9-6.7-28.3-10.5c-5.2-3.1-5.3-4.9-5.3-6.7c0-3.7 1.4-6.5 6.2-9.3c5.4-3.2 13.6-5.1 21.5-5c9.6 .1 20.2 2.2 31.2 5.2c10.7 2.8 21.6-3.5 24.5-14.2s-3.5-21.6-14.2-24.5c-6.5-1.7-13.7-3.4-21.1-4.7l0-13.9z"]};var w0={prefix:"fas",iconName:"file-chart-column",icon:[384,512,["file-chart-line"],"f659","M64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-288-128 0c-17.7 0-32-14.3-32-32L224 0 64 0zM256 0l0 128 128 0L256 0zM216 248l0 176c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-176c0-13.3 10.7-24 24-24s24 10.7 24 24zm88 64l0 112c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-112c0-13.3 10.7-24 24-24s24 10.7 24 24zM128 376l0 48c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-48c0-13.3 10.7-24 24-24s24 10.7 24 24z"]};var k0={prefix:"fas",iconName:"user-group",icon:[640,512,[128101,"user-friends"],"f500","M96 128a128 128 0 1 1 256 0A128 128 0 1 1 96 128zM0 482.3C0 383.8 79.8 304 178.3 304l91.4 0C368.2 304 448 383.8 448 482.3c0 16.4-13.3 29.7-29.7 29.7L29.7 512C13.3 512 0 498.7 0 482.3zM609.3 512l-137.8 0c5.4-9.4 8.6-20.3 8.6-32l0-8c0-60.7-27.1-115.2-69.8-151.8c2.4-.1 4.7-.2 7.1-.2l61.4 0C567.8 320 640 392.2 640 481.3c0 17-13.8 30.7-30.7 30.7zM432 256c-31 0-59-12.6-79.3-32.9C372.4 196.5 384 163.6 384 128c0-26.8-6.6-52.1-18.3-74.3C384.3 40.1 407.2 32 432 32c61.9 0 112 50.1 112 112s-50.1 112-112 112z"]};var A0={prefix:"fas",iconName:"user-tie",icon:[448,512,[],"f508","M96 128a128 128 0 1 0 256 0A128 128 0 1 0 96 128zm94.5 200.2l18.6 31L175.8 483.1l-36-146.9c-2-8.1-9.8-13.4-17.9-11.3C51.9 342.4 0 405.8 0 481.3c0 17 13.8 30.7 30.7 30.7l131.7 0c0 0 0 0 .1 0l5.5 0 112 0 5.5 0c0 0 0 0 .1 0l131.7 0c17 0 30.7-13.8 30.7-30.7c0-75.5-51.9-138.9-121.9-156.4c-8.1-2-15.9 3.3-17.9 11.3l-36 146.9L238.9 359.2l18.6-31c6.4-10.7-1.3-24.2-13.7-24.2L224 304l-19.7 0c-12.4 0-20.1 13.6-13.7 24.2z"]};var y0={prefix:"fas",iconName:"address-card",icon:[576,512,[62140,"contact-card","vcard"],"f2bb","M64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32zm80 256l64 0c44.2 0 80 35.8 80 80c0 8.8-7.2 16-16 16L80 384c-8.8 0-16-7.2-16-16c0-44.2 35.8-80 80-80zm-32-96a64 64 0 1 1 128 0 64 64 0 1 1 -128 0zm256-32l128 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-128 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zm0 64l128 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-128 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zm0 64l128 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-128 0c-8.8 0-16-7.2-16-16s7.2-16 16-16z"]};var v0={prefix:"fas",iconName:"file-image",icon:[384,512,[128443],"f1c5","M64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-288-128 0c-17.7 0-32-14.3-32-32L224 0 64 0zM256 0l0 128 128 0L256 0zM64 256a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm152 32c5.3 0 10.2 2.6 13.2 6.9l88 128c3.4 4.9 3.7 11.3 1 16.5s-8.2 8.6-14.2 8.6l-88 0-40 0-48 0-48 0c-5.8 0-11.1-3.1-13.9-8.1s-2.8-11.2 .2-16.1l48-80c2.9-4.8 8.1-7.8 13.7-7.8s10.8 2.9 13.7 7.8l12.8 21.4 48.3-70.2c3-4.3 7.9-6.9 13.2-6.9z"]};var P0={prefix:"fas",iconName:"box-circle-check",icon:[576,512,[],"e0c4","M93.7 32L208 32l0 128L0 160 50.7 58.5C58.9 42.3 75.5 32 93.7 32zM240 32l114.3 0c18.2 0 34.8 10.3 42.9 26.5L448 160l-32 0-176 0 0-128zM0 416L0 192l416 0 0 .7c-89.7 8.1-160 83.5-160 175.3c0 42.5 15.1 81.6 40.2 112L64 480c-35.3 0-64-28.7-64-64zm288-48a144 144 0 1 1 288 0 144 144 0 1 1 -288 0zm211.3-43.3c-6.2-6.2-16.4-6.2-22.6 0L416 385.4l-28.7-28.7c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l40 40c6.2 6.2 16.4 6.2 22.6 0l72-72c6.2-6.2 6.2-16.4 0-22.6z"]};var T0={prefix:"fas",iconName:"calculator",icon:[384,512,[128425],"f1ec","M64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-384c0-35.3-28.7-64-64-64L64 0zM96 64l192 0c17.7 0 32 14.3 32 32l0 32c0 17.7-14.3 32-32 32L96 160c-17.7 0-32-14.3-32-32l0-32c0-17.7 14.3-32 32-32zm32 160a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zM96 352a32 32 0 1 1 0-64 32 32 0 1 1 0 64zM64 416c0-17.7 14.3-32 32-32l96 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-96 0c-17.7 0-32-14.3-32-32zM192 256a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm32 64a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm64-64a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm32 64a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zM288 448a32 32 0 1 1 0-64 32 32 0 1 1 0 64z"]};var F0={prefix:"fas",iconName:"calendar",icon:[448,512,[128197,128198],"f133","M96 32l0 32L48 64C21.5 64 0 85.5 0 112l0 48 448 0 0-48c0-26.5-21.5-48-48-48l-48 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L160 64l0-32c0-17.7-14.3-32-32-32S96 14.3 96 32zM448 192L0 192 0 464c0 26.5 21.5 48 48 48l352 0c26.5 0 48-21.5 48-48l0-272z"]};var B0={prefix:"fas",iconName:"calendar-day",icon:[448,512,[],"f783","M128 0c17.7 0 32 14.3 32 32l0 32 128 0 0-32c0-17.7 14.3-32 32-32s32 14.3 32 32l0 32 48 0c26.5 0 48 21.5 48 48l0 48L0 160l0-48C0 85.5 21.5 64 48 64l48 0 0-32c0-17.7 14.3-32 32-32zM0 192l448 0 0 272c0 26.5-21.5 48-48 48L48 512c-26.5 0-48-21.5-48-48L0 192zm80 64c-8.8 0-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16l96 0c8.8 0 16-7.2 16-16l0-96c0-8.8-7.2-16-16-16l-96 0z"]};var l1=()=>{},U2={},w1={},k1=null,A1={mark:l1,measure:l1};try{typeof window<"u"&&(U2=window),typeof document<"u"&&(w1=document),typeof MutationObserver<"u"&&(k1=MutationObserver),typeof performance<"u"&&(A1=performance)}catch{}var{userAgent:s1=""}=U2.navigator||{},E=U2,C=w1,a1=k1,n2=A1,H0=!!E.document,H=!!C.documentElement&&!!C.head&&typeof C.addEventListener=="function"&&typeof C.createElement=="function",y1=~s1.indexOf("MSIE")||~s1.indexOf("Trident/"),p="classic",v1="duotone",b="sharp",S="sharp-duotone",h4=[p,v1,b,S],g4={classic:{900:"fas",400:"far",normal:"far",300:"fal",100:"fat"},sharp:{900:"fass",400:"fasr",300:"fasl",100:"fast"},"sharp-duotone":{900:"fasds"}},e1={kit:{fak:"kit","fa-kit":"kit"},"kit-duotone":{fakd:"kit-duotone","fa-kit-duotone":"kit-duotone"}},b4=["kit"],S4=/fa(s|r|l|t|d|b|k|kd|ss|sr|sl|st|sds)?[\-\ ]/,w4=/Font ?Awesome ?([56 ]*)(Solid|Regular|Light|Thin|Duotone|Brands|Free|Pro|Sharp Duotone|Sharp|Kit)?.*/i,k4={"Font Awesome 5 Free":{900:"fas",400:"far"},"Font Awesome 5 Pro":{900:"fas",400:"far",normal:"far",300:"fal"},"Font Awesome 5 Brands":{400:"fab",normal:"fab"},"Font Awesome 5 Duotone":{900:"fad"}},A4={"Font Awesome 6 Free":{900:"fas",400:"far"},"Font Awesome 6 Pro":{900:"fas",400:"far",normal:"far",300:"fal",100:"fat"},"Font Awesome 6 Brands":{400:"fab",normal:"fab"},"Font Awesome 6 Duotone":{900:"fad"},"Font Awesome 6 Sharp":{900:"fass",400:"fasr",normal:"fasr",300:"fasl",100:"fast"},"Font Awesome 6 Sharp Duotone":{900:"fasds"}},y4={classic:{"fa-brands":"fab","fa-duotone":"fad","fa-light":"fal","fa-regular":"far","fa-solid":"fas","fa-thin":"fat"},sharp:{"fa-solid":"fass","fa-regular":"fasr","fa-light":"fasl","fa-thin":"fast"},"sharp-duotone":{"fa-solid":"fasds"}},v4={classic:["fas","far","fal","fat"],sharp:["fass","fasr","fasl","fast"],"sharp-duotone":["fasds"]},P4={classic:{fab:"fa-brands",fad:"fa-duotone",fal:"fa-light",far:"fa-regular",fas:"fa-solid",fat:"fa-thin"},sharp:{fass:"fa-solid",fasr:"fa-regular",fasl:"fa-light",fast:"fa-thin"},"sharp-duotone":{fasds:"fa-solid"}},T4={classic:{solid:"fas",regular:"far",light:"fal",thin:"fat",duotone:"fad",brands:"fab"},sharp:{solid:"fass",regular:"fasr",light:"fasl",thin:"fast"},"sharp-duotone":{solid:"fasds"}},P1={classic:{fa:"solid",fas:"solid","fa-solid":"solid",far:"regular","fa-regular":"regular",fal:"light","fa-light":"light",fat:"thin","fa-thin":"thin",fad:"duotone","fa-duotone":"duotone",fab:"brands","fa-brands":"brands"},sharp:{fa:"solid",fass:"solid","fa-solid":"solid",fasr:"regular","fa-regular":"regular",fasl:"light","fa-light":"light",fast:"thin","fa-thin":"thin"},"sharp-duotone":{fa:"solid",fasds:"solid","fa-solid":"solid"}},F4=["solid","regular","light","thin","duotone","brands"],T1=[1,2,3,4,5,6,7,8,9,10],B4=T1.concat([11,12,13,14,15,16,17,18,19,20]),J={GROUP:"duotone-group",SWAP_OPACITY:"swap-opacity",PRIMARY:"primary",SECONDARY:"secondary"},D4=[...Object.keys(v4),...F4,"2xs","xs","sm","lg","xl","2xl","beat","border","fade","beat-fade","bounce","flip-both","flip-horizontal","flip-vertical","flip","fw","inverse","layers-counter","layers-text","layers","li","pull-left","pull-right","pulse","rotate-180","rotate-270","rotate-90","rotate-by","shake","spin-pulse","spin-reverse","spin","stack-1x","stack-2x","stack","ul",J.GROUP,J.SWAP_OPACITY,J.PRIMARY,J.SECONDARY].concat(T1.map(c=>"".concat(c,"x"))).concat(B4.map(c=>"w-".concat(c))),H4={"Font Awesome Kit":{400:"fak",normal:"fak"},"Font Awesome Kit Duotone":{400:"fakd",normal:"fakd"}},R4={kit:{"fa-kit":"fak"},"kit-duotone":{"fa-kit-duotone":"fakd"}},q4={kit:{fak:"fa-kit"},"kit-duotone":{fakd:"fa-kit-duotone"}},o1={kit:{kit:"fak"},"kit-duotone":{"kit-duotone":"fakd"}},B="___FONT_AWESOME___",S2=16,F1="fa",B1="svg-inline--fa",V="data-fa-i2svg",w2="data-fa-pseudo-element",E4="data-fa-pseudo-element-pending",O2="data-prefix",I2="data-icon",n1="fontawesome-i2svg",U4="async",O4=["HTML","HEAD","STYLE","SCRIPT"],D1=(()=>{try{return!0}catch{return!1}})(),H1=[p,b,S];function e2(c){return new Proxy(c,{get(l,s){return s in l?l[s]:l[p]}})}var R1={...P1};R1[p]={...P1[p],...e1.kit,...e1["kit-duotone"]};var W=e2(R1),k2={...T4};k2[p]={...k2[p],...o1.kit,...o1["kit-duotone"]};var s2=e2(k2),A2={...P4};A2[p]={...A2[p],...q4.kit};var G=e2(A2),y2={...y4};y2[p]={...y2[p],...R4.kit};var I4=e2(y2),W4=S4,q1="fa-layers-text",G4=w4,V4={...g4},R0=e2(V4),j4=["class","data-prefix","data-icon","data-fa-transform","data-fa-mask"],d2=J,K=new Set;Object.keys(s2[p]).map(K.add.bind(K));Object.keys(s2[b]).map(K.add.bind(K));Object.keys(s2[S]).map(K.add.bind(K));var _4=[...b4,...D4],c2=E.FontAwesomeConfig||{};function X4(c){var l=C.querySelector("script["+c+"]");if(l)return l.getAttribute(c)}function K4(c){return c===""?!0:c==="false"?!1:c==="true"?!0:c}C&&typeof C.querySelector=="function"&&[["data-family-prefix","familyPrefix"],["data-css-prefix","cssPrefix"],["data-family-default","familyDefault"],["data-style-default","styleDefault"],["data-replacement-class","replacementClass"],["data-auto-replace-svg","autoReplaceSvg"],["data-auto-add-css","autoAddCss"],["data-auto-a11y","autoA11y"],["data-search-pseudo-elements","searchPseudoElements"],["data-observe-mutations","observeMutations"],["data-mutate-approach","mutateApproach"],["data-keep-original-source","keepOriginalSource"],["data-measure-performance","measurePerformance"],["data-show-missing-icons","showMissingIcons"]].forEach(l=>{let[s,a]=l,e=K4(X4(s));e!=null&&(c2[a]=e)});var E1={styleDefault:"solid",familyDefault:"classic",cssPrefix:F1,replacementClass:B1,autoReplaceSvg:!0,autoAddCss:!0,autoA11y:!0,searchPseudoElements:!1,observeMutations:!0,mutateApproach:"async",keepOriginalSource:!0,measurePerformance:!1,showMissingIcons:!0};c2.familyPrefix&&(c2.cssPrefix=c2.familyPrefix);var Y={...E1,...c2};Y.autoReplaceSvg||(Y.observeMutations=!1);var t={};Object.keys(E1).forEach(c=>{Object.defineProperty(t,c,{enumerable:!0,set:function(l){Y[c]=l,l2.forEach(s=>s(t))},get:function(){return Y[c]}})});Object.defineProperty(t,"familyPrefix",{enumerable:!0,set:function(c){Y.cssPrefix=c,l2.forEach(l=>l(t))},get:function(){return Y.cssPrefix}});E.FontAwesomeConfig=t;var l2=[];function Y4(c){return l2.push(c),()=>{l2.splice(l2.indexOf(c),1)}}var R=S2,y={size:16,x:0,y:0,rotate:0,flipX:!1,flipY:!1};function Q4(c){if(!c||!H)return;let l=C.createElement("style");l.setAttribute("type","text/css"),l.innerHTML=c;let s=C.head.childNodes,a=null;for(let e=s.length-1;e>-1;e--){let o=s[e],n=(o.tagName||"").toUpperCase();["STYLE","LINK"].indexOf(n)>-1&&(a=o)}return C.head.insertBefore(l,a),c}var $4="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";function a2(){let c=12,l="";for(;c-- >0;)l+=$4[Math.random()*62|0];return l}function Q(c){let l=[];for(let s=(c||[]).length>>>0;s--;)l[s]=c[s];return l}function W2(c){return c.classList?Q(c.classList):(c.getAttribute("class")||"").split(" ").filter(l=>l)}function U1(c){return"".concat(c).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function J4(c){return Object.keys(c||{}).reduce((l,s)=>l+"".concat(s,'="').concat(U1(c[s]),'" '),"").trim()}function z2(c){return Object.keys(c||{}).reduce((l,s)=>l+"".concat(s,": ").concat(c[s].trim(),";"),"")}function G2(c){return c.size!==y.size||c.x!==y.x||c.y!==y.y||c.rotate!==y.rotate||c.flipX||c.flipY}function Z4(c){let{transform:l,containerWidth:s,iconWidth:a}=c,e={transform:"translate(".concat(s/2," 256)")},o="translate(".concat(l.x*32,", ").concat(l.y*32,") "),n="scale(".concat(l.size/16*(l.flipX?-1:1),", ").concat(l.size/16*(l.flipY?-1:1),") "),i="rotate(".concat(l.rotate," 0 0)"),f={transform:"".concat(o," ").concat(n," ").concat(i)},r={transform:"translate(".concat(a/2*-1," -256)")};return{outer:e,inner:f,path:r}}function c3(c){let{transform:l,width:s=S2,height:a=S2,startCentered:e=!1}=c,o="";return e&&y1?o+="translate(".concat(l.x/R-s/2,"em, ").concat(l.y/R-a/2,"em) "):e?o+="translate(calc(-50% + ".concat(l.x/R,"em), calc(-50% + ").concat(l.y/R,"em)) "):o+="translate(".concat(l.x/R,"em, ").concat(l.y/R,"em) "),o+="scale(".concat(l.size/R*(l.flipX?-1:1),", ").concat(l.size/R*(l.flipY?-1:1),") "),o+="rotate(".concat(l.rotate,"deg) "),o}var l3=`:root, :host {
  --fa-font-solid: normal 900 1em/1 "Font Awesome 6 Free";
  --fa-font-regular: normal 400 1em/1 "Font Awesome 6 Free";
  --fa-font-light: normal 300 1em/1 "Font Awesome 6 Pro";
  --fa-font-thin: normal 100 1em/1 "Font Awesome 6 Pro";
  --fa-font-duotone: normal 900 1em/1 "Font Awesome 6 Duotone";
  --fa-font-brands: normal 400 1em/1 "Font Awesome 6 Brands";
  --fa-font-sharp-solid: normal 900 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-regular: normal 400 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-light: normal 300 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-thin: normal 100 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-duotone-solid: normal 900 1em/1 "Font Awesome 6 Sharp Duotone";
}

svg:not(:root).svg-inline--fa, svg:not(:host).svg-inline--fa {
  overflow: visible;
  box-sizing: content-box;
}

.svg-inline--fa {
  display: var(--fa-display, inline-block);
  height: 1em;
  overflow: visible;
  vertical-align: -0.125em;
}
.svg-inline--fa.fa-2xs {
  vertical-align: 0.1em;
}
.svg-inline--fa.fa-xs {
  vertical-align: 0em;
}
.svg-inline--fa.fa-sm {
  vertical-align: -0.0714285705em;
}
.svg-inline--fa.fa-lg {
  vertical-align: -0.2em;
}
.svg-inline--fa.fa-xl {
  vertical-align: -0.25em;
}
.svg-inline--fa.fa-2xl {
  vertical-align: -0.3125em;
}
.svg-inline--fa.fa-pull-left {
  margin-right: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-pull-right {
  margin-left: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-li {
  width: var(--fa-li-width, 2em);
  top: 0.25em;
}
.svg-inline--fa.fa-fw {
  width: var(--fa-fw-width, 1.25em);
}

.fa-layers svg.svg-inline--fa {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
}

.fa-layers-counter, .fa-layers-text {
  display: inline-block;
  position: absolute;
  text-align: center;
}

.fa-layers {
  display: inline-block;
  height: 1em;
  position: relative;
  text-align: center;
  vertical-align: -0.125em;
  width: 1em;
}
.fa-layers svg.svg-inline--fa {
  transform-origin: center center;
}

.fa-layers-text {
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  transform-origin: center center;
}

.fa-layers-counter {
  background-color: var(--fa-counter-background-color, #ff253a);
  border-radius: var(--fa-counter-border-radius, 1em);
  box-sizing: border-box;
  color: var(--fa-inverse, #fff);
  line-height: var(--fa-counter-line-height, 1);
  max-width: var(--fa-counter-max-width, 5em);
  min-width: var(--fa-counter-min-width, 1.5em);
  overflow: hidden;
  padding: var(--fa-counter-padding, 0.25em 0.5em);
  right: var(--fa-right, 0);
  text-overflow: ellipsis;
  top: var(--fa-top, 0);
  transform: scale(var(--fa-counter-scale, 0.25));
  transform-origin: top right;
}

.fa-layers-bottom-right {
  bottom: var(--fa-bottom, 0);
  right: var(--fa-right, 0);
  top: auto;
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: bottom right;
}

.fa-layers-bottom-left {
  bottom: var(--fa-bottom, 0);
  left: var(--fa-left, 0);
  right: auto;
  top: auto;
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: bottom left;
}

.fa-layers-top-right {
  top: var(--fa-top, 0);
  right: var(--fa-right, 0);
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: top right;
}

.fa-layers-top-left {
  left: var(--fa-left, 0);
  right: auto;
  top: var(--fa-top, 0);
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: top left;
}

.fa-1x {
  font-size: 1em;
}

.fa-2x {
  font-size: 2em;
}

.fa-3x {
  font-size: 3em;
}

.fa-4x {
  font-size: 4em;
}

.fa-5x {
  font-size: 5em;
}

.fa-6x {
  font-size: 6em;
}

.fa-7x {
  font-size: 7em;
}

.fa-8x {
  font-size: 8em;
}

.fa-9x {
  font-size: 9em;
}

.fa-10x {
  font-size: 10em;
}

.fa-2xs {
  font-size: 0.625em;
  line-height: 0.1em;
  vertical-align: 0.225em;
}

.fa-xs {
  font-size: 0.75em;
  line-height: 0.0833333337em;
  vertical-align: 0.125em;
}

.fa-sm {
  font-size: 0.875em;
  line-height: 0.0714285718em;
  vertical-align: 0.0535714295em;
}

.fa-lg {
  font-size: 1.25em;
  line-height: 0.05em;
  vertical-align: -0.075em;
}

.fa-xl {
  font-size: 1.5em;
  line-height: 0.0416666682em;
  vertical-align: -0.125em;
}

.fa-2xl {
  font-size: 2em;
  line-height: 0.03125em;
  vertical-align: -0.1875em;
}

.fa-fw {
  text-align: center;
  width: 1.25em;
}

.fa-ul {
  list-style-type: none;
  margin-left: var(--fa-li-margin, 2.5em);
  padding-left: 0;
}
.fa-ul > li {
  position: relative;
}

.fa-li {
  left: calc(-1 * var(--fa-li-width, 2em));
  position: absolute;
  text-align: center;
  width: var(--fa-li-width, 2em);
  line-height: inherit;
}

.fa-border {
  border-color: var(--fa-border-color, #eee);
  border-radius: var(--fa-border-radius, 0.1em);
  border-style: var(--fa-border-style, solid);
  border-width: var(--fa-border-width, 0.08em);
  padding: var(--fa-border-padding, 0.2em 0.25em 0.15em);
}

.fa-pull-left {
  float: left;
  margin-right: var(--fa-pull-margin, 0.3em);
}

.fa-pull-right {
  float: right;
  margin-left: var(--fa-pull-margin, 0.3em);
}

.fa-beat {
  animation-name: fa-beat;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-bounce {
  animation-name: fa-bounce;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
}

.fa-fade {
  animation-name: fa-fade;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-beat-fade {
  animation-name: fa-beat-fade;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-flip {
  animation-name: fa-flip;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-shake {
  animation-name: fa-shake;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin {
  animation-name: fa-spin;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 2s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin-reverse {
  --fa-animation-direction: reverse;
}

.fa-pulse,
.fa-spin-pulse {
  animation-name: fa-spin;
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, steps(8));
}

@media (prefers-reduced-motion: reduce) {
  .fa-beat,
.fa-bounce,
.fa-fade,
.fa-beat-fade,
.fa-flip,
.fa-pulse,
.fa-shake,
.fa-spin,
.fa-spin-pulse {
    animation-delay: -1ms;
    animation-duration: 1ms;
    animation-iteration-count: 1;
    transition-delay: 0s;
    transition-duration: 0s;
  }
}
@keyframes fa-beat {
  0%, 90% {
    transform: scale(1);
  }
  45% {
    transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@keyframes fa-bounce {
  0% {
    transform: scale(1, 1) translateY(0);
  }
  10% {
    transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    transform: scale(1, 1) translateY(0);
  }
  100% {
    transform: scale(1, 1) translateY(0);
  }
}
@keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@keyframes fa-flip {
  50% {
    transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@keyframes fa-shake {
  0% {
    transform: rotate(-15deg);
  }
  4% {
    transform: rotate(15deg);
  }
  8%, 24% {
    transform: rotate(-18deg);
  }
  12%, 28% {
    transform: rotate(18deg);
  }
  16% {
    transform: rotate(-22deg);
  }
  20% {
    transform: rotate(22deg);
  }
  32% {
    transform: rotate(-12deg);
  }
  36% {
    transform: rotate(12deg);
  }
  40%, 100% {
    transform: rotate(0deg);
  }
}
@keyframes fa-spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
.fa-rotate-90 {
  transform: rotate(90deg);
}

.fa-rotate-180 {
  transform: rotate(180deg);
}

.fa-rotate-270 {
  transform: rotate(270deg);
}

.fa-flip-horizontal {
  transform: scale(-1, 1);
}

.fa-flip-vertical {
  transform: scale(1, -1);
}

.fa-flip-both,
.fa-flip-horizontal.fa-flip-vertical {
  transform: scale(-1, -1);
}

.fa-rotate-by {
  transform: rotate(var(--fa-rotate-angle, 0));
}

.fa-stack {
  display: inline-block;
  vertical-align: middle;
  height: 2em;
  position: relative;
  width: 2.5em;
}

.fa-stack-1x,
.fa-stack-2x {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  z-index: var(--fa-stack-z-index, auto);
}

.svg-inline--fa.fa-stack-1x {
  height: 1em;
  width: 1.25em;
}
.svg-inline--fa.fa-stack-2x {
  height: 2em;
  width: 2.5em;
}

.fa-inverse {
  color: var(--fa-inverse, #fff);
}

.sr-only,
.fa-sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.sr-only-focusable:not(:focus),
.fa-sr-only-focusable:not(:focus) {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.svg-inline--fa .fa-primary {
  fill: var(--fa-primary-color, currentColor);
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa .fa-secondary {
  fill: var(--fa-secondary-color, currentColor);
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-primary {
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-secondary {
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa mask .fa-primary,
.svg-inline--fa mask .fa-secondary {
  fill: black;
}

.fad.fa-inverse,
.fa-duotone.fa-inverse {
  color: var(--fa-inverse, #fff);
}`;function O1(){let c=F1,l=B1,s=t.cssPrefix,a=t.replacementClass,e=l3;if(s!==c||a!==l){let o=new RegExp("\\.".concat(c,"\\-"),"g"),n=new RegExp("\\--".concat(c,"\\-"),"g"),i=new RegExp("\\.".concat(l),"g");e=e.replace(o,".".concat(s,"-")).replace(n,"--".concat(s,"-")).replace(i,".".concat(a))}return e}var i1=!1;function N2(){t.autoAddCss&&!i1&&(Q4(O1()),i1=!0)}var s3={mixout(){return{dom:{css:O1,insertCss:N2}}},hooks(){return{beforeDOMElementCreation(){N2()},beforeI2svg(){N2()}}}},D=E||{};D[B]||(D[B]={});D[B].styles||(D[B].styles={});D[B].hooks||(D[B].hooks={});D[B].shims||(D[B].shims=[]);var v=D[B],I1=[],W1=function(){C.removeEventListener("DOMContentLoaded",W1),r2=1,I1.map(c=>c())},r2=!1;H&&(r2=(C.documentElement.doScroll?/^loaded|^c/:/^loaded|^i|^c/).test(C.readyState),r2||C.addEventListener("DOMContentLoaded",W1));function a3(c){H&&(r2?setTimeout(c,0):I1.push(c))}function o2(c){let{tag:l,attributes:s={},children:a=[]}=c;return typeof c=="string"?U1(c):"<".concat(l," ").concat(J4(s),">").concat(a.map(o2).join(""),"</").concat(l,">")}function f1(c,l,s){if(c&&c[l]&&c[l][s])return{prefix:l,iconName:s,icon:c[l][s]}}var e3=function(l,s){return function(a,e,o,n){return l.call(s,a,e,o,n)}},h2=function(l,s,a,e){var o=Object.keys(l),n=o.length,i=e!==void 0?e3(s,e):s,f,r,z;for(a===void 0?(f=1,z=l[o[0]]):(f=0,z=a);f<n;f++)r=o[f],z=i(z,l[r],r,l);return z};function o3(c){let l=[],s=0,a=c.length;for(;s<a;){let e=c.charCodeAt(s++);if(e>=55296&&e<=56319&&s<a){let o=c.charCodeAt(s++);(o&64512)==56320?l.push(((e&1023)<<10)+(o&1023)+65536):(l.push(e),s--)}else l.push(e)}return l}function v2(c){let l=o3(c);return l.length===1?l[0].toString(16):null}function n3(c,l){let s=c.length,a=c.charCodeAt(l),e;return a>=55296&&a<=56319&&s>l+1&&(e=c.charCodeAt(l+1),e>=56320&&e<=57343)?(a-55296)*1024+e-56320+65536:a}function r1(c){return Object.keys(c).reduce((l,s)=>{let a=c[s];return!!a.icon?l[a.iconName]=a.icon:l[s]=a,l},{})}function P2(c,l){let s=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{},{skipHooks:a=!1}=s,e=r1(l);typeof v.hooks.addPack=="function"&&!a?v.hooks.addPack(c,r1(l)):v.styles[c]={...v.styles[c]||{},...e},c==="fas"&&P2("fa",l)}var{styles:I,shims:i3}=v,f3={[p]:Object.values(G[p]),[b]:Object.values(G[b]),[S]:Object.values(G[S])},V2=null,G1={},V1={},j1={},_1={},X1={},r3={[p]:Object.keys(W[p]),[b]:Object.keys(W[b]),[S]:Object.keys(W[S])};function t3(c){return~_4.indexOf(c)}function z3(c,l){let s=l.split("-"),a=s[0],e=s.slice(1).join("-");return a===c&&e!==""&&!t3(e)?e:null}var K1=()=>{let c=a=>h2(I,(e,o,n)=>(e[n]=h2(o,a,{}),e),{});G1=c((a,e,o)=>(e[3]&&(a[e[3]]=o),e[2]&&e[2].filter(i=>typeof i=="number").forEach(i=>{a[i.toString(16)]=o}),a)),V1=c((a,e,o)=>(a[o]=o,e[2]&&e[2].filter(i=>typeof i=="string").forEach(i=>{a[i]=o}),a)),X1=c((a,e,o)=>{let n=e[2];return a[o]=o,n.forEach(i=>{a[i]=o}),a});let l="far"in I||t.autoFetchSvg,s=h2(i3,(a,e)=>{let o=e[0],n=e[1],i=e[2];return n==="far"&&!l&&(n="fas"),typeof o=="string"&&(a.names[o]={prefix:n,iconName:i}),typeof o=="number"&&(a.unicodes[o.toString(16)]={prefix:n,iconName:i}),a},{names:{},unicodes:{}});j1=s.names,_1=s.unicodes,V2=L2(t.styleDefault,{family:t.familyDefault})};Y4(c=>{V2=L2(c.styleDefault,{family:t.familyDefault})});K1();function j2(c,l){return(G1[c]||{})[l]}function L3(c,l){return(V1[c]||{})[l]}function q(c,l){return(X1[c]||{})[l]}function Y1(c){return j1[c]||{prefix:null,iconName:null}}function m3(c){let l=_1[c],s=j2("fas",c);return l||(s?{prefix:"fas",iconName:s}:null)||{prefix:null,iconName:null}}function U(){return V2}var _2=()=>({prefix:null,iconName:null,rest:[]});function L2(c){let l=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},{family:s=p}=l,a=W[s][c],e=s2[s][c]||s2[s][a],o=c in v.styles?c:null;return e||o||null}var M3={[p]:Object.keys(G[p]),[b]:Object.keys(G[b]),[S]:Object.keys(G[S])};function m2(c){let l=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},{skipLookups:s=!1}=l,a={[p]:"".concat(t.cssPrefix,"-").concat(p),[b]:"".concat(t.cssPrefix,"-").concat(b),[S]:"".concat(t.cssPrefix,"-").concat(S)},e=null,o=p,n=h4.filter(f=>f!==v1);n.forEach(f=>{(c.includes(a[f])||c.some(r=>M3[f].includes(r)))&&(o=f)});let i=c.reduce((f,r)=>{let z=z3(t.cssPrefix,r);if(I[r]?(r=f3[o].includes(r)?I4[o][r]:r,e=r,f.prefix=r):r3[o].indexOf(r)>-1?(e=r,f.prefix=L2(r,{family:o})):z?f.iconName=z:r!==t.replacementClass&&!n.some(M=>r===a[M])&&f.rest.push(r),!s&&f.prefix&&f.iconName){let M=e==="fa"?Y1(f.iconName):{},m=q(f.prefix,f.iconName);M.prefix&&(e=null),f.iconName=M.iconName||m||f.iconName,f.prefix=M.prefix||f.prefix,f.prefix==="far"&&!I.far&&I.fas&&!t.autoFetchSvg&&(f.prefix="fas")}return f},_2());return(c.includes("fa-brands")||c.includes("fab"))&&(i.prefix="fab"),(c.includes("fa-duotone")||c.includes("fad"))&&(i.prefix="fad"),!i.prefix&&o===b&&(I.fass||t.autoFetchSvg)&&(i.prefix="fass",i.iconName=q(i.prefix,i.iconName)||i.iconName),!i.prefix&&o===S&&(I.fasds||t.autoFetchSvg)&&(i.prefix="fasds",i.iconName=q(i.prefix,i.iconName)||i.iconName),(i.prefix==="fa"||e==="fa")&&(i.prefix=U()||"fas"),i}var T2=class{constructor(){this.definitions={}}add(){for(var l=arguments.length,s=new Array(l),a=0;a<l;a++)s[a]=arguments[a];let e=s.reduce(this._pullDefinitions,{});Object.keys(e).forEach(o=>{this.definitions[o]={...this.definitions[o]||{},...e[o]},P2(o,e[o]);let n=G[p][o];n&&P2(n,e[o]),K1()})}reset(){this.definitions={}}_pullDefinitions(l,s){let a=s.prefix&&s.iconName&&s.icon?{0:s}:s;return Object.keys(a).map(e=>{let{prefix:o,iconName:n,icon:i}=a[e],f=i[2];l[o]||(l[o]={}),f.length>0&&f.forEach(r=>{typeof r=="string"&&(l[o][r]=i)}),l[o][n]=i}),l}},t1=[],_={},X={},C3=Object.keys(X);function p3(c,l){let{mixoutsTo:s}=l;return t1=c,_={},Object.keys(X).forEach(a=>{C3.indexOf(a)===-1&&delete X[a]}),t1.forEach(a=>{let e=a.mixout?a.mixout():{};if(Object.keys(e).forEach(o=>{typeof e[o]=="function"&&(s[o]=e[o]),typeof e[o]=="object"&&Object.keys(e[o]).forEach(n=>{s[o]||(s[o]={}),s[o][n]=e[o][n]})}),a.hooks){let o=a.hooks();Object.keys(o).forEach(n=>{_[n]||(_[n]=[]),_[n].push(o[n])})}a.provides&&a.provides(X)}),s}function F2(c,l){for(var s=arguments.length,a=new Array(s>2?s-2:0),e=2;e<s;e++)a[e-2]=arguments[e];return(_[c]||[]).forEach(n=>{l=n.apply(null,[l,...a])}),l}function j(c){for(var l=arguments.length,s=new Array(l>1?l-1:0),a=1;a<l;a++)s[a-1]=arguments[a];(_[c]||[]).forEach(o=>{o.apply(null,s)})}function O(){let c=arguments[0],l=Array.prototype.slice.call(arguments,1);return X[c]?X[c].apply(null,l):void 0}function B2(c){c.prefix==="fa"&&(c.prefix="fas");let{iconName:l}=c,s=c.prefix||U();if(l)return l=q(s,l)||l,f1(Q1.definitions,s,l)||f1(v.styles,s,l)}var Q1=new T2,x3=()=>{t.autoReplaceSvg=!1,t.observeMutations=!1,j("noAuto")},u3={i2svg:function(){let c=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};return H?(j("beforeI2svg",c),O("pseudoElements2svg",c),O("i2svg",c)):Promise.reject(new Error("Operation requires a DOM of some kind."))},watch:function(){let c=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},{autoReplaceSvgRoot:l}=c;t.autoReplaceSvg===!1&&(t.autoReplaceSvg=!0),t.observeMutations=!0,a3(()=>{N3({autoReplaceSvgRoot:l}),j("watch",c)})}},d3={icon:c=>{if(c===null)return null;if(typeof c=="object"&&c.prefix&&c.iconName)return{prefix:c.prefix,iconName:q(c.prefix,c.iconName)||c.iconName};if(Array.isArray(c)&&c.length===2){let l=c[1].indexOf("fa-")===0?c[1].slice(3):c[1],s=L2(c[0]);return{prefix:s,iconName:q(s,l)||l}}if(typeof c=="string"&&(c.indexOf("".concat(t.cssPrefix,"-"))>-1||c.match(W4))){let l=m2(c.split(" "),{skipLookups:!0});return{prefix:l.prefix||U(),iconName:q(l.prefix,l.iconName)||l.iconName}}if(typeof c=="string"){let l=U();return{prefix:l,iconName:q(l,c)||c}}}},w={noAuto:x3,config:t,dom:u3,parse:d3,library:Q1,findIconDefinition:B2,toHtml:o2},N3=function(){let c=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},{autoReplaceSvgRoot:l=C}=c;(Object.keys(v.styles).length>0||t.autoFetchSvg)&&H&&t.autoReplaceSvg&&w.dom.i2svg({node:l})};function M2(c,l){return Object.defineProperty(c,"abstract",{get:l}),Object.defineProperty(c,"html",{get:function(){return c.abstract.map(s=>o2(s))}}),Object.defineProperty(c,"node",{get:function(){if(!H)return;let s=C.createElement("div");return s.innerHTML=c.html,s.children}}),c}function h3(c){let{children:l,main:s,mask:a,attributes:e,styles:o,transform:n}=c;if(G2(n)&&s.found&&!a.found){let{width:i,height:f}=s,r={x:i/f/2,y:.5};e.style=z2({...o,"transform-origin":"".concat(r.x+n.x/16,"em ").concat(r.y+n.y/16,"em")})}return[{tag:"svg",attributes:e,children:l}]}function g3(c){let{prefix:l,iconName:s,children:a,attributes:e,symbol:o}=c,n=o===!0?"".concat(l,"-").concat(t.cssPrefix,"-").concat(s):o;return[{tag:"svg",attributes:{style:"display: none;"},children:[{tag:"symbol",attributes:{...e,id:n},children:a}]}]}function X2(c){let{icons:{main:l,mask:s},prefix:a,iconName:e,transform:o,symbol:n,title:i,maskId:f,titleId:r,extra:z,watchable:M=!1}=c,{width:m,height:u}=s.found?s:l,g=a==="fak",k=[t.replacementClass,e?"".concat(t.cssPrefix,"-").concat(e):""].filter(A=>z.classes.indexOf(A)===-1).filter(A=>A!==""||!!A).concat(z.classes).join(" "),x={children:[],attributes:{...z.attributes,"data-prefix":a,"data-icon":e,class:k,role:z.attributes.role||"img",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 ".concat(m," ").concat(u)}},N=g&&!~z.classes.indexOf("fa-fw")?{width:"".concat(m/u*16*.0625,"em")}:{};M&&(x.attributes[V]=""),i&&(x.children.push({tag:"title",attributes:{id:x.attributes["aria-labelledby"]||"title-".concat(r||a2())},children:[i]}),delete x.attributes.title);let d={...x,prefix:a,iconName:e,main:l,mask:s,maskId:f,transform:o,symbol:n,styles:{...N,...z.styles}},{children:h,attributes:F}=s.found&&l.found?O("generateAbstractMask",d)||{children:[],attributes:{}}:O("generateAbstractIcon",d)||{children:[],attributes:{}};return d.children=h,d.attributes=F,n?g3(d):h3(d)}function z1(c){let{content:l,width:s,height:a,transform:e,title:o,extra:n,watchable:i=!1}=c,f={...n.attributes,...o?{title:o}:{},class:n.classes.join(" ")};i&&(f[V]="");let r={...n.styles};G2(e)&&(r.transform=c3({transform:e,startCentered:!0,width:s,height:a}),r["-webkit-transform"]=r.transform);let z=z2(r);z.length>0&&(f.style=z);let M=[];return M.push({tag:"span",attributes:f,children:[l]}),o&&M.push({tag:"span",attributes:{class:"sr-only"},children:[o]}),M}function b3(c){let{content:l,title:s,extra:a}=c,e={...a.attributes,...s?{title:s}:{},class:a.classes.join(" ")},o=z2(a.styles);o.length>0&&(e.style=o);let n=[];return n.push({tag:"span",attributes:e,children:[l]}),s&&n.push({tag:"span",attributes:{class:"sr-only"},children:[s]}),n}var{styles:g2}=v;function D2(c){let l=c[0],s=c[1],[a]=c.slice(4),e=null;return Array.isArray(a)?e={tag:"g",attributes:{class:"".concat(t.cssPrefix,"-").concat(d2.GROUP)},children:[{tag:"path",attributes:{class:"".concat(t.cssPrefix,"-").concat(d2.SECONDARY),fill:"currentColor",d:a[0]}},{tag:"path",attributes:{class:"".concat(t.cssPrefix,"-").concat(d2.PRIMARY),fill:"currentColor",d:a[1]}}]}:e={tag:"path",attributes:{fill:"currentColor",d:a}},{found:!0,width:l,height:s,icon:e}}var S3={found:!1,width:512,height:512};function w3(c,l){!D1&&!t.showMissingIcons&&c&&console.error('Icon with name "'.concat(c,'" and prefix "').concat(l,'" is missing.'))}function H2(c,l){let s=l;return l==="fa"&&t.styleDefault!==null&&(l=U()),new Promise((a,e)=>{if(s==="fa"){let o=Y1(c)||{};c=o.iconName||c,l=o.prefix||l}if(c&&l&&g2[l]&&g2[l][c]){let o=g2[l][c];return a(D2(o))}w3(c,l),a({...S3,icon:t.showMissingIcons&&c?O("missingIconAbstract")||{}:{}})})}var L1=()=>{},R2=t.measurePerformance&&n2&&n2.mark&&n2.measure?n2:{mark:L1,measure:L1},Z='FA "6.6.0"',k3=c=>(R2.mark("".concat(Z," ").concat(c," begins")),()=>$1(c)),$1=c=>{R2.mark("".concat(Z," ").concat(c," ends")),R2.measure("".concat(Z," ").concat(c),"".concat(Z," ").concat(c," begins"),"".concat(Z," ").concat(c," ends"))},K2={begin:k3,end:$1},i2=()=>{};function m1(c){return typeof(c.getAttribute?c.getAttribute(V):null)=="string"}function A3(c){let l=c.getAttribute?c.getAttribute(O2):null,s=c.getAttribute?c.getAttribute(I2):null;return l&&s}function y3(c){return c&&c.classList&&c.classList.contains&&c.classList.contains(t.replacementClass)}function v3(){return t.autoReplaceSvg===!0?f2.replace:f2[t.autoReplaceSvg]||f2.replace}function P3(c){return C.createElementNS("http://www.w3.org/2000/svg",c)}function T3(c){return C.createElement(c)}function J1(c){let l=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},{ceFn:s=c.tag==="svg"?P3:T3}=l;if(typeof c=="string")return C.createTextNode(c);let a=s(c.tag);return Object.keys(c.attributes||[]).forEach(function(o){a.setAttribute(o,c.attributes[o])}),(c.children||[]).forEach(function(o){a.appendChild(J1(o,{ceFn:s}))}),a}function F3(c){let l=" ".concat(c.outerHTML," ");return l="".concat(l,"Font Awesome fontawesome.com "),l}var f2={replace:function(c){let l=c[0];if(l.parentNode)if(c[1].forEach(s=>{l.parentNode.insertBefore(J1(s),l)}),l.getAttribute(V)===null&&t.keepOriginalSource){let s=C.createComment(F3(l));l.parentNode.replaceChild(s,l)}else l.remove()},nest:function(c){let l=c[0],s=c[1];if(~W2(l).indexOf(t.replacementClass))return f2.replace(c);let a=new RegExp("".concat(t.cssPrefix,"-.*"));if(delete s[0].attributes.id,s[0].attributes.class){let o=s[0].attributes.class.split(" ").reduce((n,i)=>(i===t.replacementClass||i.match(a)?n.toSvg.push(i):n.toNode.push(i),n),{toNode:[],toSvg:[]});s[0].attributes.class=o.toSvg.join(" "),o.toNode.length===0?l.removeAttribute("class"):l.setAttribute("class",o.toNode.join(" "))}let e=s.map(o=>o2(o)).join(`
`);l.setAttribute(V,""),l.innerHTML=e}};function M1(c){c()}function Z1(c,l){let s=typeof l=="function"?l:i2;if(c.length===0)s();else{let a=M1;t.mutateApproach===U4&&(a=E.requestAnimationFrame||M1),a(()=>{let e=v3(),o=K2.begin("mutate");c.map(e),o(),s()})}}var Y2=!1;function c4(){Y2=!0}function q2(){Y2=!1}var t2=null;function C1(c){if(!a1||!t.observeMutations)return;let{treeCallback:l=i2,nodeCallback:s=i2,pseudoElementsCallback:a=i2,observeMutationsRoot:e=C}=c;t2=new a1(o=>{if(Y2)return;let n=U();Q(o).forEach(i=>{if(i.type==="childList"&&i.addedNodes.length>0&&!m1(i.addedNodes[0])&&(t.searchPseudoElements&&a(i.target),l(i.target)),i.type==="attributes"&&i.target.parentNode&&t.searchPseudoElements&&a(i.target.parentNode),i.type==="attributes"&&m1(i.target)&&~j4.indexOf(i.attributeName))if(i.attributeName==="class"&&A3(i.target)){let{prefix:f,iconName:r}=m2(W2(i.target));i.target.setAttribute(O2,f||n),r&&i.target.setAttribute(I2,r)}else y3(i.target)&&s(i.target)})}),H&&t2.observe(e,{childList:!0,attributes:!0,characterData:!0,subtree:!0})}function B3(){t2&&t2.disconnect()}function D3(c){let l=c.getAttribute("style"),s=[];return l&&(s=l.split(";").reduce((a,e)=>{let o=e.split(":"),n=o[0],i=o.slice(1);return n&&i.length>0&&(a[n]=i.join(":").trim()),a},{})),s}function H3(c){let l=c.getAttribute("data-prefix"),s=c.getAttribute("data-icon"),a=c.innerText!==void 0?c.innerText.trim():"",e=m2(W2(c));return e.prefix||(e.prefix=U()),l&&s&&(e.prefix=l,e.iconName=s),e.iconName&&e.prefix||(e.prefix&&a.length>0&&(e.iconName=L3(e.prefix,c.innerText)||j2(e.prefix,v2(c.innerText))),!e.iconName&&t.autoFetchSvg&&c.firstChild&&c.firstChild.nodeType===Node.TEXT_NODE&&(e.iconName=c.firstChild.data)),e}function R3(c){let l=Q(c.attributes).reduce((e,o)=>(e.name!=="class"&&e.name!=="style"&&(e[o.name]=o.value),e),{}),s=c.getAttribute("title"),a=c.getAttribute("data-fa-title-id");return t.autoA11y&&(s?l["aria-labelledby"]="".concat(t.replacementClass,"-title-").concat(a||a2()):(l["aria-hidden"]="true",l.focusable="false")),l}function q3(){return{iconName:null,title:null,titleId:null,prefix:null,transform:y,symbol:!1,mask:{iconName:null,prefix:null,rest:[]},maskId:null,extra:{classes:[],styles:{},attributes:{}}}}function p1(c){let l=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{styleParser:!0},{iconName:s,prefix:a,rest:e}=H3(c),o=R3(c),n=F2("parseNodeAttributes",{},c),i=l.styleParser?D3(c):[];return{iconName:s,title:c.getAttribute("title"),titleId:c.getAttribute("data-fa-title-id"),prefix:a,transform:y,mask:{iconName:null,prefix:null,rest:[]},maskId:null,symbol:!1,extra:{classes:e,styles:i,attributes:o},...n}}var{styles:E3}=v;function l4(c){let l=t.autoReplaceSvg==="nest"?p1(c,{styleParser:!1}):p1(c);return~l.extra.classes.indexOf(q1)?O("generateLayersText",c,l):O("generateSvgReplacementMutation",c,l)}var P=new Set;H1.map(c=>{P.add("fa-".concat(c))});Object.keys(W[p]).map(P.add.bind(P));Object.keys(W[b]).map(P.add.bind(P));Object.keys(W[S]).map(P.add.bind(P));P=[...P];function x1(c){let l=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;if(!H)return Promise.resolve();let s=C.documentElement.classList,a=z=>s.add("".concat(n1,"-").concat(z)),e=z=>s.remove("".concat(n1,"-").concat(z)),o=t.autoFetchSvg?P:H1.map(z=>"fa-".concat(z)).concat(Object.keys(E3));o.includes("fa")||o.push("fa");let n=[".".concat(q1,":not([").concat(V,"])")].concat(o.map(z=>".".concat(z,":not([").concat(V,"])"))).join(", ");if(n.length===0)return Promise.resolve();let i=[];try{i=Q(c.querySelectorAll(n))}catch{}if(i.length>0)a("pending"),e("complete");else return Promise.resolve();let f=K2.begin("onTree"),r=i.reduce((z,M)=>{try{let m=l4(M);m&&z.push(m)}catch(m){D1||m.name==="MissingIcon"&&console.error(m)}return z},[]);return new Promise((z,M)=>{Promise.all(r).then(m=>{Z1(m,()=>{a("active"),a("complete"),e("pending"),typeof l=="function"&&l(),f(),z()})}).catch(m=>{f(),M(m)})})}function U3(c){let l=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;l4(c).then(s=>{s&&Z1([s],l)})}function O3(c){return function(l){let s=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},a=(l||{}).icon?l:B2(l||{}),{mask:e}=s;return e&&(e=(e||{}).icon?e:B2(e||{})),c(a,{...s,mask:e})}}var I3=function(c){let l=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},{transform:s=y,symbol:a=!1,mask:e=null,maskId:o=null,title:n=null,titleId:i=null,classes:f=[],attributes:r={},styles:z={}}=l;if(!c)return;let{prefix:M,iconName:m,icon:u}=c;return M2({type:"icon",...c},()=>(j("beforeDOMElementCreation",{iconDefinition:c,params:l}),t.autoA11y&&(n?r["aria-labelledby"]="".concat(t.replacementClass,"-title-").concat(i||a2()):(r["aria-hidden"]="true",r.focusable="false")),X2({icons:{main:D2(u),mask:e?D2(e.icon):{found:!1,width:null,height:null,icon:{}}},prefix:M,iconName:m,transform:{...y,...s},symbol:a,title:n,maskId:o,titleId:i,extra:{attributes:r,styles:z,classes:f}})))},W3={mixout(){return{icon:O3(I3)}},hooks(){return{mutationObserverCallbacks(c){return c.treeCallback=x1,c.nodeCallback=U3,c}}},provides(c){c.i2svg=function(l){let{node:s=C,callback:a=()=>{}}=l;return x1(s,a)},c.generateSvgReplacementMutation=function(l,s){let{iconName:a,title:e,titleId:o,prefix:n,transform:i,symbol:f,mask:r,maskId:z,extra:M}=s;return new Promise((m,u)=>{Promise.all([H2(a,n),r.iconName?H2(r.iconName,r.prefix):Promise.resolve({found:!1,width:512,height:512,icon:{}})]).then(g=>{let[k,x]=g;m([l,X2({icons:{main:k,mask:x},prefix:n,iconName:a,transform:i,symbol:f,maskId:z,title:e,titleId:o,extra:M,watchable:!0})])}).catch(u)})},c.generateAbstractIcon=function(l){let{children:s,attributes:a,main:e,transform:o,styles:n}=l,i=z2(n);i.length>0&&(a.style=i);let f;return G2(o)&&(f=O("generateAbstractTransformGrouping",{main:e,transform:o,containerWidth:e.width,iconWidth:e.width})),s.push(f||e.icon),{children:s,attributes:a}}}},G3={mixout(){return{layer(c){let l=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},{classes:s=[]}=l;return M2({type:"layer"},()=>{j("beforeDOMElementCreation",{assembler:c,params:l});let a=[];return c(e=>{Array.isArray(e)?e.map(o=>{a=a.concat(o.abstract)}):a=a.concat(e.abstract)}),[{tag:"span",attributes:{class:["".concat(t.cssPrefix,"-layers"),...s].join(" ")},children:a}]})}}}},V3={mixout(){return{counter(c){let l=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},{title:s=null,classes:a=[],attributes:e={},styles:o={}}=l;return M2({type:"counter",content:c},()=>(j("beforeDOMElementCreation",{content:c,params:l}),b3({content:c.toString(),title:s,extra:{attributes:e,styles:o,classes:["".concat(t.cssPrefix,"-layers-counter"),...a]}})))}}}},j3={mixout(){return{text(c){let l=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},{transform:s=y,title:a=null,classes:e=[],attributes:o={},styles:n={}}=l;return M2({type:"text",content:c},()=>(j("beforeDOMElementCreation",{content:c,params:l}),z1({content:c,transform:{...y,...s},title:a,extra:{attributes:o,styles:n,classes:["".concat(t.cssPrefix,"-layers-text"),...e]}})))}}},provides(c){c.generateLayersText=function(l,s){let{title:a,transform:e,extra:o}=s,n=null,i=null;if(y1){let f=parseInt(getComputedStyle(l).fontSize,10),r=l.getBoundingClientRect();n=r.width/f,i=r.height/f}return t.autoA11y&&!a&&(o.attributes["aria-hidden"]="true"),Promise.resolve([l,z1({content:l.innerHTML,width:n,height:i,transform:e,title:a,extra:o,watchable:!0})])}}},_3=new RegExp('"',"ug"),u1=[1105920,1112319],d1={FontAwesome:{normal:"fas",400:"fas"},...A4,...k4,...H4},E2=Object.keys(d1).reduce((c,l)=>(c[l.toLowerCase()]=d1[l],c),{}),X3=Object.keys(E2).reduce((c,l)=>{let s=E2[l];return c[l]=s[900]||[...Object.entries(s)][0][1],c},{});function K3(c){let l=c.replace(_3,""),s=n3(l,0),a=s>=u1[0]&&s<=u1[1],e=l.length===2?l[0]===l[1]:!1;return{value:v2(e?l[0]:l),isSecondary:a||e}}function Y3(c,l){let s=c.replace(/^['"]|['"]$/g,"").toLowerCase(),a=parseInt(l),e=isNaN(a)?"normal":a;return(E2[s]||{})[e]||X3[s]}function N1(c,l){let s="".concat(E4).concat(l.replace(":","-"));return new Promise((a,e)=>{if(c.getAttribute(s)!==null)return a();let n=Q(c.children).filter(m=>m.getAttribute(w2)===l)[0],i=E.getComputedStyle(c,l),f=i.getPropertyValue("font-family"),r=f.match(G4),z=i.getPropertyValue("font-weight"),M=i.getPropertyValue("content");if(n&&!r)return c.removeChild(n),a();if(r&&M!=="none"&&M!==""){let m=i.getPropertyValue("content"),u=Y3(f,z),{value:g,isSecondary:k}=K3(m),x=r[0].startsWith("FontAwesome"),N=j2(u,g),d=N;if(x){let h=m3(g);h.iconName&&h.prefix&&(N=h.iconName,u=h.prefix)}if(N&&!k&&(!n||n.getAttribute(O2)!==u||n.getAttribute(I2)!==d)){c.setAttribute(s,d),n&&c.removeChild(n);let h=q3(),{extra:F}=h;F.attributes[w2]=l,H2(N,u).then(A=>{let u4=X2({...h,icons:{main:A,mask:_2()},prefix:u,iconName:d,extra:F,watchable:!0}),x2=C.createElementNS("http://www.w3.org/2000/svg","svg");l==="::before"?c.insertBefore(x2,c.firstChild):c.appendChild(x2),x2.outerHTML=u4.map(d4=>o2(d4)).join(`
`),c.removeAttribute(s),a()}).catch(e)}else a()}else a()})}function Q3(c){return Promise.all([N1(c,"::before"),N1(c,"::after")])}function $3(c){return c.parentNode!==document.head&&!~O4.indexOf(c.tagName.toUpperCase())&&!c.getAttribute(w2)&&(!c.parentNode||c.parentNode.tagName!=="svg")}function h1(c){if(H)return new Promise((l,s)=>{let a=Q(c.querySelectorAll("*")).filter($3).map(Q3),e=K2.begin("searchPseudoElements");c4(),Promise.all(a).then(()=>{e(),q2(),l()}).catch(()=>{e(),q2(),s()})})}var J3={hooks(){return{mutationObserverCallbacks(c){return c.pseudoElementsCallback=h1,c}}},provides(c){c.pseudoElements2svg=function(l){let{node:s=C}=l;t.searchPseudoElements&&h1(s)}}},g1=!1,Z3={mixout(){return{dom:{unwatch(){c4(),g1=!0}}}},hooks(){return{bootstrap(){C1(F2("mutationObserverCallbacks",{}))},noAuto(){B3()},watch(c){let{observeMutationsRoot:l}=c;g1?q2():C1(F2("mutationObserverCallbacks",{observeMutationsRoot:l}))}}}},b1=c=>{let l={size:16,x:0,y:0,flipX:!1,flipY:!1,rotate:0};return c.toLowerCase().split(" ").reduce((s,a)=>{let e=a.toLowerCase().split("-"),o=e[0],n=e.slice(1).join("-");if(o&&n==="h")return s.flipX=!0,s;if(o&&n==="v")return s.flipY=!0,s;if(n=parseFloat(n),isNaN(n))return s;switch(o){case"grow":s.size=s.size+n;break;case"shrink":s.size=s.size-n;break;case"left":s.x=s.x-n;break;case"right":s.x=s.x+n;break;case"up":s.y=s.y-n;break;case"down":s.y=s.y+n;break;case"rotate":s.rotate=s.rotate+n;break}return s},l)},c0={mixout(){return{parse:{transform:c=>b1(c)}}},hooks(){return{parseNodeAttributes(c,l){let s=l.getAttribute("data-fa-transform");return s&&(c.transform=b1(s)),c}}},provides(c){c.generateAbstractTransformGrouping=function(l){let{main:s,transform:a,containerWidth:e,iconWidth:o}=l,n={transform:"translate(".concat(e/2," 256)")},i="translate(".concat(a.x*32,", ").concat(a.y*32,") "),f="scale(".concat(a.size/16*(a.flipX?-1:1),", ").concat(a.size/16*(a.flipY?-1:1),") "),r="rotate(".concat(a.rotate," 0 0)"),z={transform:"".concat(i," ").concat(f," ").concat(r)},M={transform:"translate(".concat(o/2*-1," -256)")},m={outer:n,inner:z,path:M};return{tag:"g",attributes:{...m.outer},children:[{tag:"g",attributes:{...m.inner},children:[{tag:s.icon.tag,children:s.icon.children,attributes:{...s.icon.attributes,...m.path}}]}]}}}},b2={x:0,y:0,width:"100%",height:"100%"};function S1(c){let l=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!0;return c.attributes&&(c.attributes.fill||l)&&(c.attributes.fill="black"),c}function l0(c){return c.tag==="g"?c.children:[c]}var s0={hooks(){return{parseNodeAttributes(c,l){let s=l.getAttribute("data-fa-mask"),a=s?m2(s.split(" ").map(e=>e.trim())):_2();return a.prefix||(a.prefix=U()),c.mask=a,c.maskId=l.getAttribute("data-fa-mask-id"),c}}},provides(c){c.generateAbstractMask=function(l){let{children:s,attributes:a,main:e,mask:o,maskId:n,transform:i}=l,{width:f,icon:r}=e,{width:z,icon:M}=o,m=Z4({transform:i,containerWidth:z,iconWidth:f}),u={tag:"rect",attributes:{...b2,fill:"white"}},g=r.children?{children:r.children.map(S1)}:{},k={tag:"g",attributes:{...m.inner},children:[S1({tag:r.tag,attributes:{...r.attributes,...m.path},...g})]},x={tag:"g",attributes:{...m.outer},children:[k]},N="mask-".concat(n||a2()),d="clip-".concat(n||a2()),h={tag:"mask",attributes:{...b2,id:N,maskUnits:"userSpaceOnUse",maskContentUnits:"userSpaceOnUse"},children:[u,x]},F={tag:"defs",children:[{tag:"clipPath",attributes:{id:d},children:l0(M)},h]};return s.push(F,{tag:"rect",attributes:{fill:"currentColor","clip-path":"url(#".concat(d,")"),mask:"url(#".concat(N,")"),...b2}}),{children:s,attributes:a}}}},a0={provides(c){let l=!1;E.matchMedia&&(l=E.matchMedia("(prefers-reduced-motion: reduce)").matches),c.missingIconAbstract=function(){let s=[],a={fill:"currentColor"},e={attributeType:"XML",repeatCount:"indefinite",dur:"2s"};s.push({tag:"path",attributes:{...a,d:"M156.5,447.7l-12.6,29.5c-18.7-9.5-35.9-21.2-51.5-34.9l22.7-22.7C127.6,430.5,141.5,440,156.5,447.7z M40.6,272H8.5 c1.4,21.2,5.4,41.7,11.7,61.1L50,321.2C45.1,305.5,41.8,289,40.6,272z M40.6,240c1.4-18.8,5.2-37,11.1-54.1l-29.5-12.6 C14.7,194.3,10,216.7,8.5,240H40.6z M64.3,156.5c7.8-14.9,17.2-28.8,28.1-41.5L69.7,92.3c-13.7,15.6-25.5,32.8-34.9,51.5 L64.3,156.5z M397,419.6c-13.9,12-29.4,22.3-46.1,30.4l11.9,29.8c20.7-9.9,39.8-22.6,56.9-37.6L397,419.6z M115,92.4 c13.9-12,29.4-22.3,46.1-30.4l-11.9-29.8c-20.7,9.9-39.8,22.6-56.8,37.6L115,92.4z M447.7,355.5c-7.8,14.9-17.2,28.8-28.1,41.5 l22.7,22.7c13.7-15.6,25.5-32.9,34.9-51.5L447.7,355.5z M471.4,272c-1.4,18.8-5.2,37-11.1,54.1l29.5,12.6 c7.5-21.1,12.2-43.5,13.6-66.8H471.4z M321.2,462c-15.7,5-32.2,8.2-49.2,9.4v32.1c21.2-1.4,41.7-5.4,61.1-11.7L321.2,462z M240,471.4c-18.8-1.4-37-5.2-54.1-11.1l-12.6,29.5c21.1,7.5,43.5,12.2,66.8,13.6V471.4z M462,190.8c5,15.7,8.2,32.2,9.4,49.2h32.1 c-1.4-21.2-5.4-41.7-11.7-61.1L462,190.8z M92.4,397c-12-13.9-22.3-29.4-30.4-46.1l-29.8,11.9c9.9,20.7,22.6,39.8,37.6,56.9 L92.4,397z M272,40.6c18.8,1.4,36.9,5.2,54.1,11.1l12.6-29.5C317.7,14.7,295.3,10,272,8.5V40.6z M190.8,50 c15.7-5,32.2-8.2,49.2-9.4V8.5c-21.2,1.4-41.7,5.4-61.1,11.7L190.8,50z M442.3,92.3L419.6,115c12,13.9,22.3,29.4,30.5,46.1 l29.8-11.9C470,128.5,457.3,109.4,442.3,92.3z M397,92.4l22.7-22.7c-15.6-13.7-32.8-25.5-51.5-34.9l-12.6,29.5 C370.4,72.1,384.4,81.5,397,92.4z"}});let o={...e,attributeName:"opacity"},n={tag:"circle",attributes:{...a,cx:"256",cy:"364",r:"28"},children:[]};return l||n.children.push({tag:"animate",attributes:{...e,attributeName:"r",values:"28;14;28;28;14;28;"}},{tag:"animate",attributes:{...o,values:"1;0;1;1;0;1;"}}),s.push(n),s.push({tag:"path",attributes:{...a,opacity:"1",d:"M263.7,312h-16c-6.6,0-12-5.4-12-12c0-71,77.4-63.9,77.4-107.8c0-20-17.8-40.2-57.4-40.2c-29.1,0-44.3,9.6-59.2,28.7 c-3.9,5-11.1,6-16.2,2.4l-13.1-9.2c-5.6-3.9-6.9-11.8-2.6-17.2c21.2-27.2,46.4-44.7,91.2-44.7c52.3,0,97.4,29.8,97.4,80.2 c0,67.6-77.4,63.5-77.4,107.8C275.7,306.6,270.3,312,263.7,312z"},children:l?[]:[{tag:"animate",attributes:{...o,values:"1;0;0;0;0;1;"}}]}),l||s.push({tag:"path",attributes:{...a,opacity:"0",d:"M232.5,134.5l7,168c0.3,6.4,5.6,11.5,12,11.5h9c6.4,0,11.7-5.1,12-11.5l7-168c0.3-6.8-5.2-12.5-12-12.5h-23 C237.7,122,232.2,127.7,232.5,134.5z"},children:[{tag:"animate",attributes:{...o,values:"0;0;1;1;0;0;"}}]}),{tag:"g",attributes:{class:"missing"},children:s}}}},e0={hooks(){return{parseNodeAttributes(c,l){let s=l.getAttribute("data-fa-symbol"),a=s===null?!1:s===""?!0:s;return c.symbol=a,c}}}},o0=[s3,W3,G3,V3,j3,J3,Z3,c0,s0,a0,e0];p3(o0,{mixoutsTo:w});var q0=w.noAuto,E0=w.config,U0=w.library,O0=w.dom,C2=w.parse,I0=w.findIconDefinition,W0=w.toHtml,s4=w.icon,G0=w.layer,V0=w.text,j0=w.counter;var L=c1(t4()),Z2=c1(N4());function z4(c,l){var s=Object.keys(c);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(c);l&&(a=a.filter(function(e){return Object.getOwnPropertyDescriptor(c,e).enumerable})),s.push.apply(s,a)}return s}function T(c){for(var l=1;l<arguments.length;l++){var s=arguments[l]!=null?arguments[l]:{};l%2?z4(Object(s),!0).forEach(function(a){$(c,a,s[a])}):Object.getOwnPropertyDescriptors?Object.defineProperties(c,Object.getOwnPropertyDescriptors(s)):z4(Object(s)).forEach(function(a){Object.defineProperty(c,a,Object.getOwnPropertyDescriptor(s,a))})}return c}function p2(c){"@babel/helpers - typeof";return p2=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(l){return typeof l}:function(l){return l&&typeof Symbol=="function"&&l.constructor===Symbol&&l!==Symbol.prototype?"symbol":typeof l},p2(c)}function $(c,l,s){return l in c?Object.defineProperty(c,l,{value:s,enumerable:!0,configurable:!0,writable:!0}):c[l]=s,c}function f0(c,l){if(c==null)return{};var s={},a=Object.keys(c),e,o;for(o=0;o<a.length;o++)e=a[o],!(l.indexOf(e)>=0)&&(s[e]=c[e]);return s}function r0(c,l){if(c==null)return{};var s=f0(c,l),a,e;if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(c);for(e=0;e<o.length;e++)a=o[e],!(l.indexOf(a)>=0)&&Object.prototype.propertyIsEnumerable.call(c,a)&&(s[a]=c[a])}return s}function $2(c){return t0(c)||z0(c)||L0(c)||m0()}function t0(c){if(Array.isArray(c))return J2(c)}function z0(c){if(typeof Symbol<"u"&&c[Symbol.iterator]!=null||c["@@iterator"]!=null)return Array.from(c)}function L0(c,l){if(c){if(typeof c=="string")return J2(c,l);var s=Object.prototype.toString.call(c).slice(8,-1);if(s==="Object"&&c.constructor&&(s=c.constructor.name),s==="Map"||s==="Set")return Array.from(c);if(s==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(s))return J2(c,l)}}function J2(c,l){(l==null||l>c.length)&&(l=c.length);for(var s=0,a=new Array(l);s<l;s++)a[s]=c[s];return a}function m0(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function M0(c){var l,s=c.beat,a=c.fade,e=c.beatFade,o=c.bounce,n=c.shake,i=c.flash,f=c.spin,r=c.spinPulse,z=c.spinReverse,M=c.pulse,m=c.fixedWidth,u=c.inverse,g=c.border,k=c.listItem,x=c.flip,N=c.size,d=c.rotation,h=c.pull,F=(l={"fa-beat":s,"fa-fade":a,"fa-beat-fade":e,"fa-bounce":o,"fa-shake":n,"fa-flash":i,"fa-spin":f,"fa-spin-reverse":z,"fa-spin-pulse":r,"fa-pulse":M,"fa-fw":m,"fa-inverse":u,"fa-border":g,"fa-li":k,"fa-flip":x===!0,"fa-flip-horizontal":x==="horizontal"||x==="both","fa-flip-vertical":x==="vertical"||x==="both"},$(l,"fa-".concat(N),typeof N<"u"&&N!==null),$(l,"fa-rotate-".concat(d),typeof d<"u"&&d!==null&&d!==0),$(l,"fa-pull-".concat(h),typeof h<"u"&&h!==null),$(l,"fa-swap-opacity",c.swapOpacity),l);return Object.keys(F).map(function(A){return F[A]?A:null}).filter(function(A){return A})}function C0(c){return c=c-0,c===c}function M4(c){return C0(c)?c:(c=c.replace(/[\-_\s]+(.)?/g,function(l,s){return s?s.toUpperCase():""}),c.substr(0,1).toLowerCase()+c.substr(1))}var p0=["style"];function x0(c){return c.charAt(0).toUpperCase()+c.slice(1)}function u0(c){return c.split(";").map(function(l){return l.trim()}).filter(function(l){return l}).reduce(function(l,s){var a=s.indexOf(":"),e=M4(s.slice(0,a)),o=s.slice(a+1).trim();return e.startsWith("webkit")?l[x0(e)]=o:l[e]=o,l},{})}function C4(c,l){var s=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{};if(typeof l=="string")return l;var a=(l.children||[]).map(function(f){return C4(c,f)}),e=Object.keys(l.attributes||{}).reduce(function(f,r){var z=l.attributes[r];switch(r){case"class":f.attrs.className=z,delete l.attributes.class;break;case"style":f.attrs.style=u0(z);break;default:r.indexOf("aria-")===0||r.indexOf("data-")===0?f.attrs[r.toLowerCase()]=z:f.attrs[M4(r)]=z}return f},{attrs:{}}),o=s.style,n=o===void 0?{}:o,i=r0(s,p0);return e.attrs.style=T(T({},e.attrs.style),n),c.apply(void 0,[l.tag,T(T({},e.attrs),i)].concat($2(a)))}var p4=!1;try{p4=!0}catch{}function d0(){if(!p4&&console&&typeof console.error=="function"){var c;(c=console).error.apply(c,arguments)}}function L4(c){if(c&&p2(c)==="object"&&c.prefix&&c.iconName&&c.icon)return c;if(C2.icon)return C2.icon(c);if(c===null)return null;if(c&&p2(c)==="object"&&c.prefix&&c.iconName)return c;if(Array.isArray(c)&&c.length===2)return{prefix:c[0],iconName:c[1]};if(typeof c=="string")return{prefix:"fas",iconName:c}}function Q2(c,l){return Array.isArray(l)&&l.length>0||!Array.isArray(l)&&l?$({},c,l):{}}var m4={border:!1,className:"",mask:null,maskId:null,fixedWidth:!1,inverse:!1,flip:!1,icon:null,listItem:!1,pull:null,pulse:!1,rotation:null,size:null,spin:!1,spinPulse:!1,spinReverse:!1,beat:!1,fade:!1,beatFade:!1,bounce:!1,shake:!1,symbol:!1,title:"",titleId:null,transform:null,swapOpacity:!1},x4=Z2.default.forwardRef(function(c,l){var s=T(T({},m4),c),a=s.icon,e=s.mask,o=s.symbol,n=s.className,i=s.title,f=s.titleId,r=s.maskId,z=L4(a),M=Q2("classes",[].concat($2(M0(s)),$2((n||"").split(" ")))),m=Q2("transform",typeof s.transform=="string"?C2.transform(s.transform):s.transform),u=Q2("mask",L4(e)),g=s4(z,T(T(T(T({},M),m),u),{},{symbol:o,title:i,titleId:f,maskId:r}));if(!g)return d0("Could not find icon",z),null;var k=g.abstract,x={ref:l};return Object.keys(s).forEach(function(N){m4.hasOwnProperty(N)||(x[N]=s[N])}),N0(k[0],x)});x4.displayName="FontAwesomeIcon";x4.propTypes={beat:L.default.bool,border:L.default.bool,beatFade:L.default.bool,bounce:L.default.bool,className:L.default.string,fade:L.default.bool,flash:L.default.bool,mask:L.default.oneOfType([L.default.object,L.default.array,L.default.string]),maskId:L.default.string,fixedWidth:L.default.bool,inverse:L.default.bool,flip:L.default.oneOf([!0,!1,"horizontal","vertical","both"]),icon:L.default.oneOfType([L.default.object,L.default.array,L.default.string]),listItem:L.default.bool,pull:L.default.oneOf(["right","left"]),pulse:L.default.bool,rotation:L.default.oneOf([0,90,180,270]),shake:L.default.bool,size:L.default.oneOf(["2xs","xs","sm","lg","xl","2xl","1x","2x","3x","4x","5x","6x","7x","8x","9x","10x"]),spin:L.default.bool,spinPulse:L.default.bool,spinReverse:L.default.bool,symbol:L.default.oneOfType([L.default.bool,L.default.string]),title:L.default.string,titleId:L.default.string,transform:L.default.oneOfType([L.default.string,L.default.object]),swapOpacity:L.default.bool};var N0=C4.bind(null,Z2.default.createElement);export{h0 as a,g0 as b,b0 as c,S0 as d,w0 as e,k0 as f,A0 as g,y0 as h,v0 as i,P0 as j,T0 as k,F0 as l,B0 as m,t4 as n,x4 as o};
