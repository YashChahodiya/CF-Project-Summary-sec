var t=r=>{let n=parseFloat(r)/100;return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",minimumFractionDigits:2,maximumFractionDigits:2}).format(n)};export{t as a};
